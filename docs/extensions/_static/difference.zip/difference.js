Numbas.queueScript('extensions/difference/difference.js',['jme'],function() {
    var difference = Numbas.extensions.difference = {};
    var extensionScope = difference.scope = new Numbas.jme.Scope();

    var funcObj = Numbas.jme.funcObj;
    var TNum = Numbas.jme.types.TNum;

    extensionScope.addFunction(new funcObj('difference',[TNum,TNum],TNum,function(a,b){ return Math.abs(a-b); }, {unwrapValues:true}));
})

